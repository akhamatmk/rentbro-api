<?php

namespace Rentalbro\Models\Mysql;

use Illuminate\Database\Eloquent\Model;

class Administrator extends Model
{
	protected $table = 'users';
}
