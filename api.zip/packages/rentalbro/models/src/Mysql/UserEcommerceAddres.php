<?php

namespace Rentalbro\Models\Mysql;

use Illuminate\Database\Eloquent\Model;

class UserEcommerceAddres extends Model
{
	protected $table = 'user_ecommerce_address';
}
